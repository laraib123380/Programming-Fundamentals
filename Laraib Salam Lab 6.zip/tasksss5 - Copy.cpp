#include <iostream>
using namespace std;

int main() {
    const int days = 7;
    float temp, sum = 0;

    for(int i = 1; i <= days; i++) {
        cout << "Enter temperature for day " << i << ": ";
        cin >> temp;
        sum += temp;
    }

    float average = sum / days;
    cout << "Average temperature for the week: " << average << endl;

return 0;
}