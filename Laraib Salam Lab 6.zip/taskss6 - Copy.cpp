#include <iostream>
using namespace std;

int main() {
    float balance, withdrawal;

    cout << "Enter initial balance: ";
    cin >> balance;

    while (true) {
        cout << "Enter withdrawal amount (0 to exit): ";
        cin >> withdrawal;

        if (withdrawal == 0) {
            break;
        }

        if (withdrawal > balance) {
            cout << "Insufficient balance!" << endl;
        } else {
            balance -= withdrawal;
            cout << "Withdrawal successful. Remaining balance: " << balance << endl;
        }
    }

    cout << "Final balance: " << balance << endl;

    return 0;
}