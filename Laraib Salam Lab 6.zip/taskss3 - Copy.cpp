#include <iostream>
using namespace std;

int main() {
    int number, sum = 0;
    
    cout << "Enter numbers (enter a negative number to stop): " << endl;

    while (true) {
        cin >> number;
        if (number < 0)
            break;
        sum += number;
    }
cout<<"total sum:"<<sum<<endl;
return 0;
}