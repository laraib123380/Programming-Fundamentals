#include<iostream>

int main() {
    for (int i = 2; i <= 20; i += 3) {
        cout << i << " ";
    }
    cout << endl;
    return 0;
}

