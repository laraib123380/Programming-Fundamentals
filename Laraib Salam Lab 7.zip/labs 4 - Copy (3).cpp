#include <iostream>
using namespace std;

int main()
 {
    int choice;
    do {
        cout << "\nMenu:\n";
        cout << "1. Print Hello\n";
        cout << "2. Print World\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Hello\n";
                break;
            case 2:
                cout << "World\n";
                break;
            case 3:
                cout << "Exiting...\n";
                break;
return o;
}

