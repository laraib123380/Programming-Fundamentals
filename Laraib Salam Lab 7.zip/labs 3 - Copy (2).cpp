#include <iostream>
using namespace std;

int main() 
	{
    srand(time 0); 
    int secret = rand() % 100 + 1;  
    int guess;

    cout << "Guess the secret number between 1 and 100: ";
    while (true) {
        cin >> guess;
        if (guess == secret) {
            cout << "Congratulations! You guessed the number." << endl;
            break;
        } else if (guess < secret) {
            cout << "Too low! Try again: ";
        } else {
            cout << "Too high! Try again: ";
        }
    }
    return 0;
}


---
