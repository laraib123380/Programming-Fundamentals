#include <iostream>
#include <string>
using namespace std;

int main() {
    string password = "secret";
    string input;
    int attempts = 0;

    do {
        cout << "Enter the password: ";
        cin >> input;
        attempts++;
        if (input == password) {
            cout << "Access granted!" << endl;
            break;
        } else {
            cout << "Incorrect password. Try again." << endl;
        }
    } while (attempts < 3);

    if (attempts == 3 && input != password) {
        cout << "Access denied. Too many attempts." << endl;
    }
    return 0;
}


