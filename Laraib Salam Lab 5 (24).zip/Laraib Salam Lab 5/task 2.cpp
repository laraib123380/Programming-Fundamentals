#include<iostream>
#include<conio.h>
int main()
{
float area,perimeter;
double length, width;
std::cout<<"Enter length "<< std::endl;
std::cin>>length;
std::cout<<"Enter width "<< std::endl;
std::cin>>width;
area=length*width;
std::cout<<"Area of Rectangle is "<< area << std::endl;
perimeter= 2*(length+width);
std::cout<<"Perimeter of Rectangle is "<< perimeter<< std::endl;
getch();
}