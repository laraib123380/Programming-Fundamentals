#include<iostream>
#include<conio.h>
int main()
{
int age;
std::cout<<"Enter Age"<<std::endl;
std::cin>>age;
if(age<18){
	std::cout<<"You are a minor"<<std::endl;
}
else{
	std::cout<<"You are an adult"<<std::endl;
}
getch();
}