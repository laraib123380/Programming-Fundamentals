#include <iostream>
#include <conio.h>
int main() {
    float marks1, marks2, marks3, TotalMarks;

    std::cout << "Enter marks for three subjects:" << std::endl;
    std::cout << "Subject 1: ";
    std::cin >> marks1;
    std::cout << "Subject 2: ";
    std::cin >> marks2;
    std::cout << "Subject 3: ";
    std::cin >> marks3;
    
    TotalMarks = (marks1 + marks2 + marks3);

    if (TotalMarks >= 90) {
        std::cout << "Grade: A" << std::endl;
    } else if (TotalMarks >= 80) {
        std::cout << "Grade: B" << std::endl;
    } else if (TotalMarks >= 70) {
        std::cout << "Grade: C" << std::endl;
    } else if (TotalMarks >= 60) {
        std::cout << "Grade: D" << std::endl;
    } else {
        std::cout << "Grade: F" << std::endl;
    }

    return 0;
}
