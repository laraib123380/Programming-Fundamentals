#include<iostream>
#include<conio.h>
int main()
{
int number;
std::cout<<"Enter a number"<<std::endl;
std::cin>>number;
if(number%2==0){
	std::cout<<"The number is even"<<std::endl;
}
else{
	std::cout<<"The number is odd"<<std::endl;
}
getch();
}