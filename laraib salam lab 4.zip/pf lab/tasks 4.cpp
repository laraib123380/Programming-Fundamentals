#include <iostream>
using namespace std;
int main()
{
int day;
switch(day)
{
case1:
	cout<<"start of the workweek"<<endl;
	break;
	case2:
	cout<<"its tuesday,stay productive"<<endl;
	break;
	case4:
	cout<<"almost the weekend"<<endl;
	break;
	case5:
	cout<<"TGIF!"<<endl;
	break;
	case7:
	cout<<"enjoy your sunday!<<endl";
	break;
	default:
	cout<<"invalid day selection"<<endl;
	break;
	} 	
return 0;
}



