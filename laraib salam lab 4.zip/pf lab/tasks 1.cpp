#include <iostream>
using namespace std;
int main()
{
int age;
cout<<"enter your age:";
cin>>age;
if(age<0)
{
	
	cout<<"invalid age "<<endl;
}
else if(age<=12)
{
	cout<<"child"<<endl;
}
else if(age>13&&age<=19)
{
	if(age==13)
{
	cout<<"just a teen"<<endl;
}
else
{
	cout<<"teenager"<<endl;
}
elseif(age>=20&&age<=60)
{
	cout"adult"<<endl;
}
elseif(age>60)
{
	cout<<"senior citizen"<<endl;
}
return0;
}

{

cout<<"the number is small"<<endl;
}
else if(num<0)
if(num<-100)
{

cout<<"the number is very small"<<endl;
}
else
{

cout<<"the number is small and negative"<<endl;
}
else
{
	cout<<"the number is zero"<<endl;
}
return 0;
}
