#include <iostream>
using namespace std;
int main()
{
char service;
double amount,balance=10000.00,charges;
cout<<"select a bank operation:\n";
cout<<"D=Deposit\nW=withdraw\nt=trasfer\n";
cout<<"enter your choice:";
cin>>service;
cout<<"enter your amount:";
cin>>amount;
switch(service)
{
	case'D':
	case'd':
		charges=0.005*amount;//0.5%charges
		balance+=(amount-charges);
		cout<<"desposited:"<<amount-charge<<endl;
		cout<<"charges:<<charge<<endl";
		break;
		case'W'
		case"w"
charge=0.015*amount;//1.5%charges
if(amount+charges<=balance)
{
	balance=(amount+charges);
	cout<<"withdrawn:"<<amount<<endl;
	cout<<"charge:"<<charges<<endl;
}
break;
case'T'
case't'
charges=0.025*amount;//2.5%charges
if(amount+charge<=balance){
	balance=(amount+charges)
	cout<<"transferred:"<<amount<<endl;
	cout<<"charge:"<<charges<<endl;
}
else{
	cout<<"insufficient balance"<<endl;
}
break;
default:
	cout<<"invalid operation"<<endl;
	return0;
}


