#include <iostream>
using namespace std;
void cube(int &n) {
    n = n * n * n;  
}
int main() {
    int num;    
    cout << "Enter an integer (0 to quit): ";
    cin >> num;
    while (num != 0) {
        cube(num);   
        cout << "The cube of the entered number is: " << num << endl;
        cout<<"enter an integer(0 to quit):";
        cin>>num;
    }
    cout<<"program terminated."<<endl;
    return 0;
}
       
