#include <iostream>
using namespace std;
int cube(int n) {
    return n * n * n; 
}
int main() {
    int num;
    cout << "Enter an integer (0 to quit): ";
    cin >> num;
    while (num != 0) {
        cout << "The cube of " << num << " is: " << cube(num) << endl;
        cout << "Enter an integer (0 to quit): ";
        cin >> num;
    }
    cout<<"program terminated."<<endl;
    return 0;
}
