#include <iostream>
using namespace std;
int findLargest(int a, int b, int c) {
        return a; 
    }
    else if (b >= a && b >= c) {
        return b;  
    else {
        return c;  
    }
}
int main() {
    int x, y, z;
     cout << "Enter three integers: ";
    cin >> x >> y >> z; 
    int largest = findLargest(x, y, z);
    cout << "The largest integer is: " << largest << endl;

    return 0;
}