#include <iostream>
using namespace std;
void swap(int a, int b) {
    int temp = a;
    a = b;
    b = temp;
    cout << "Inside swap function: a = " << a << ", b = " << b << endl;
}
int main() {
    int x, y;   
    cout << "Enter the first number (x): ";
    cin >> x;
    cout << "Enter the second number (y): ";
    cin >> y;     
    cout << "Before swap: x = " << x << ", y = " << y << endl;
cout<<"After swapping :x="<<x<<",y="<<y<<endl;
return 0;
}
  