#include <iostream>
using namespace std;
void findLargest(int &a, int &b, int &c) {
    if (a >= b && a >= c) {
        cout << "The largest integer is: " << a << endl;
    }
    else if (b >= a && b >= c) {
        cout << "The largest integer is: " << b << endl;
    }
    else {
        cout << "The largest integer is: " << c << endl;
    }
}
int main() {
    int x, y, z; 
    cout << "Enter three integers: ";
    cin >> x >> y >> z;
return 0;
}
