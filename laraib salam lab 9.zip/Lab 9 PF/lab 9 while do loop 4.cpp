#include<iostream>
using namespace std;
int main ()	{			
    int num, factorial = 1;
    cout << "Enter a positive integer: ";
    cin >> num;
    do {
        int i = num;    
        do {
            factorial *= i; 
            i--; 
        } while (i > 1);  
        
        break;  
    } while (num > 1); 
    cout << "Factorial of " << num << " is: " << factorial << endl;

    return 0;
}