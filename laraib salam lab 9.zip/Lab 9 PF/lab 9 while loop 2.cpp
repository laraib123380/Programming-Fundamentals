#include <iostream>
using namespace std;

int main() {
    int i = 0;  
    while (i <= 5) {
        int j = 0;  
      
        cout << "Multiplication table of " << i << ":\n";
        while (j <= 10) {
            cout << i << " * " << j << " = " << i * j << endl;
            j++;  
        }
        cout << endl; 
        i++;  
    }

    return 0;
}