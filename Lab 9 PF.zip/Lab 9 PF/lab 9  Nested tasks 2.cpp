#include <iostream>
using namespace std;

int main() {
    int rows = 9;  
    int stars = 9; 
    for (int i = 1; i <= rows; i++) {
     w
        for (int j = 1; j <= stars; j++) {
            cout << "*";  
        }
        cout << endl;  
    }
    
    return 0;
}