#include <iostream>
using namespace std;
int main() {
    int num, factorial = 1;
    cout << "Enter a positive integer: ";
    cin >> num;
    while (num > 1) {
        int i = num;   
        while (i > 1) {
            factorial *= i;
            i--;  
        }
        break;  
    }

  
    cout << "Factorial of " << num << " is: " << factorial << endl;

    return 0;
}