#include<iostream>
using namespace std;
int main(){				
    int num, sum = 0;
    cout << "Enter a positive integer: ";
    cin >> num; 
    do {
        int temp = num;
        do {
            sum += temp % 10;  
            temp /= 10;  
        } while (temp > 0); 

        break; 
    } while (num > 0); 
    cout << "Sum of the digits is: " << sum << endl;
    return 0;
}