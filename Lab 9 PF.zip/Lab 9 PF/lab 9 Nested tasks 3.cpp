#include <iostream>
using namespace std;
int main() {
    int n;
    long long factorial = 1; 
    cout << "Enter a positive integer: ";
    cin >> n;
    if (n < 0) {
        cout << "Factorial is not defined for negative numbers." << endl;
    } else {
       
        for (int i = 1; i <= n; i++) {
            // Inner loop: 
            for (int j = 1; j <= 1; j++) {
                factorial *= i;  
            }
        }

        cout << "The factorial of " << n << " is " << factorial << endl;
    }

    return 0;
}