#include <iostream>
using namespace std;
int main() {
    int num, sum = 0;
    cout << "Enter a positive integer: ";
    cin >> num;
    while (num > 0) {
        int temp = num;
        while (temp > 0) {
            sum += temp % 10; 
            temp /= 10;
        }

        break;  
    }
    cout << "Sum of the digits is: " << sum << endl;
return 0;
}